The Springs School Lahore website

Included:
- index.html
- assets/school-logo.png (provided school logo)
- assets/school-banner-1.png (provided banner)
- assets/school-collage.png (provided school collage/banner)
- assets/iqbal-knowledge-banner.png (knowledge banner)
- realistic-looking stationery/product images

WhatsApp: 03413322777
Location: Near Noor Park, Kachwana Road, Kahna Nau, Lahore
Principal: Shahid Mehmood
